#ifndef FILE_H_H_H
#define FILE_H_H_H

#include <ifstream>
#include <ofstream>

class IFile{
private:
	std::string name;
	char sep;
public:
	IFile(std::string f);
	bool hasNext();
	std::string readLine();
	std::string readString();
	char readChar();
	int readInt();
	long readLong();
	float readFloat();
	double readDouble();
};
class OFile{
private:
	std::string name;
public:
	OFile(std::string f);
	int writeLine(std::string str);
	int writeString(std::string str);
	int writeChar(char ch);
	int writeInt(int value);
	int writeLong(long value);
	int writeFloat(float value);
	int writeDouble(double value);
}

#endif
