#ifndef FILE_H_H_H
#define FILE_H_H_H

#include <fstream>
#include <fstream>
#include <stdlib.h>
using namespace std;

class IFile{
private:
	std::string name;
	ifstream fin;
	char sep;
public:
	IFile(string f,char p=','):name(f),sep(p){
		fin.open(name.c_str());
	}
	bool hasNext(){
		if(fin.eof()) return false;
		return true;
	}
	string readLine(){
		string str;
		getline(fin,str);
		return str;
	}
	string readString(){
		string str;
		getline(fin,str,sep);
		return str;
	}
	char readChar(){
		string str;
		getline(fin,str,sep);
		return str[0];
	}
	int readInt(){
		string str;
		getline(fin,str,sep);
		int n=atoi(str.c_str());
		return n;
	}
	long readLong(){
		string str;
		getline(fin,str,sep);
		long n=atol(str.c_str());
		return n;
	}
	float readFloat(){
		string str;
		getline(fin,str,sep);
		float n=atof(str.c_str());
		return n;
	}
	double readDouble(){
		string str;
		getline(fin,str,sep);
		double n=atof(str.c_str());
		return n;
	}
	void close(){ fin.close();}
};
class OFile{
private:
	string name;
	char sep;
	ofstream fout;
	bool endLine;
public:
	OFile(string f,char p=',') : name(f),sep(p) {fout.open(name.c_str());endLine=true;}
	void writeLine(std::string str){fout<<str<<endl;endLine=true;}
	void writeString(std::string str){ endLine==true ? fout<<str:fout<<sep<<str;endLine=false;}
	void writeChar(char ch) { endLine==true ? fout<<ch:fout<<sep<<ch;endLine=false;}
	void writeInt(int value){ endLine==true ? fout<<value :fout<<sep<<value;endLine=false;}
	void writeLong(long value){endLine==true ?fout<<value:fout<<sep<<value;endLine=false;}
	void writeFloat(float value){endLine==true ? fout<<value:fout<<sep<<value;endLine=false;}
	void writeDouble(double value){endLine=true ? fout<<value : fout<<sep<<value;endLine=false;}
	void newLine(){fout<<endl;endLine=true;} 
	void close() {fout.close();}
};

#endif
