#include <stdio.h>

void test_1(char* p){
	printf("%x\n",p);
	p[1]='X';
	printf("%s\n",p);
}
void test_2(char arr[]){
	printf("%x\n",arr);
	arr[1]='Y';
	printf("%s\n",arr);
}

int main(){
//	test_1("ABC");
	test_2("ABC");
	return 0;
}
