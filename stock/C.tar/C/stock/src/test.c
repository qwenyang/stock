#include <stdio.h>
#include <iostream>
#include <vector>
#include "data.hpp"
#include "tool.hpp"

using namespace std;
using namespace stock;
using namespace yangwq;

void stringSplit(){
	string str="210,10.12,abc";
	loadString(str);
	int a=nextInt();
	double b=nextDouble();
	string c=nextString();
	cout<<a<<" "<<b<<" "<<c<<endl;	
}
void vectorTool(){
	vector<double> da;
	for(int i=0;i<10;i++) da.push_back(i);
	vector<double> vec=vectorSubset(da,0,4);
	for(int i=0;i<vec.size();i++) cout<<vec[i]<<endl;
}
void stockTest(){
	string id="600533";
	vector<Attr> dat=data(id);
	vector< vector<Attr> > sd=dynamicDataSplit(dat,0.15);
	cout<<sd.size()<<endl;
	for(int i=0;i<sd.size();i++){
		vector<Attr> ele=sd[i];
		cout<<ele[0].Date<<" "<<ele[ele.size()-1].Date<<endl;
	}
}
int main(){
//	stringSplit();
//	vectorTool();
	stockTest();
	/*vector<string> ids=IdList();
	for(int k=0;k<ids.size();k++){                                                                                                      
		 cout<<ids[k]<<endl;
	} */                
	return 0;
}
