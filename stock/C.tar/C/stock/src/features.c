#include <iostream>
#include "data.hpp"
#include "function.hpp"

using namespace std;
using namespace stock;

vector<Instance>  getFeatures(string id,int step);
int getLabel(vector<Attr> vec,int s,int num);
void run(int step);

int main(){
	/*vector<Instance> data=getFeatures("600018",1);
	for(int i=0;i<data.size();i++){
		cout<<data[i].label<<"  ";
		for(int j=0;j<data[i].feat.size();j++) cout<<data[i].feat[j]<<" ";
		cout<<endl;
	}*/
	run(1);
	return 0;
}
void run(int step){
	string dir=dFeaturesDay;
	if (step>2) dir=dFeaturesWeek;
	vector<string> ids=IdList();
	for(int k=0;k<ids.size();k++){	
		//cout<<ids[k]<<endl;
		vector<Instance> data=getFeatures(ids[k],step);
		OFile fs(dir+ids[k]);
		char buf[100];
		for(int i=0;i<data.size();i++){
			sprintf(buf,"%d",data[i].label);
			string line=buf;
			for(int j=0;j<data[i].feat.size();j++) {
				sprintf(buf,"%.8lf",data[i].feat[j]);
				line+=","+buf;
			}
			fs.writeLine(line);
		}
	}
}
// global static information
double gMaxPrice=0;
double gMinPrice=0;
double gMeanPrice=0;
double gMidPrice=0;
double gMaxVolume=0;
double gMinVolume=0;
double gMeanVolume=0;
double gMidVolume=0;

void initGlobal(vector<Attr> dat){
	gMaxPrice=maxInVector(dat,'H');
	gMinPrice=minInVector(dat,'L');
	gMeanPrice=meanInVector(dat,'M');
	gMidPrice=meanInVector(dat,'M');

	gMaxVolume=maxInVector(dat,'V');
	gMinVolume=minInVector(dat,'V');
	gMeanVolume=meanInVector(dat,'V');
	gMidVolume=midInVector(dat,'V');

}

double Price_gMax(vector<Attr> vec,int s){
	double ans=0;
	ans=vec[s].Close/gMaxPrice;
	return ans;
}

double Volume_gMax(vector<Attr> vec,int s){
	double ans=0;
	ans=vec[s].Volume/gMaxVolume;
	return ans;
}

double Price_Close_Open(vector<Attr> vec,int s){
	double ans=0;
	ans=(vec[s].Close-vec[s].Open)/vec[s].Open;
	return ans;
}

double Price_High_Low(vector<Attr> vec,int s){
	double ans=0;
	ans=(vec[s].High-vec[s].Low)/vec[s].Low;
	return ans;
}

double Price_Close_Low(vector<Attr> vec,int s){
	double ans=0;
	ans=(vec[s].Close-vec[s].Low)/vec[s].Close;
	return ans;
}

double Price_High_Close(vector<Attr> vec,int s){
	double ans=0;
	ans=(vec[s].High-vec[s].Close)/vec[s].Close;
	return ans;
}

double Reg_Price_Close_Open(vector<Attr> vec,int s,int base_days){
	double ans=0;
	ans=(vec[s].Close-vec[s+base_days-1].Open)/vec[s].Close;
	return ans;
}

double Reg_Price_High_Low(vector<Attr> vec,int s,int base_days){
	double ans=0;
	double hp=maxInVector(vec.begin()+s,vec.begin()+s+base_days,'H');
	double lp=minInVector(vec.begin()+s,vec.begin()+s+base_days,'L');
	ans=(hp-lp)/lp;
	return ans;
}

double Reg_Price_High_Close(vector<Attr> vec,int s,int base_days){
	double ans=0;
	double hp=maxInVector(vec.begin()+s,vec.begin()+s+base_days,'H');
	ans=(hp-vec[s].Close)/vec[s].Close;
	return ans;
}


double Reg_Price_Close_Low(vector<Attr> vec,int s,int base_days){
	double ans=0;
	double lp=minInVector(vec.begin()+s,vec.begin()+s+base_days,'L');
	ans=(vec[s].Close-lp)/vec[s].Close;
	return ans;
}

double Reg_Volume_gMax(vector<Attr> vec,int s,int base_days){
	double ans=0;
	double hp=meanInVector(vec.begin()+s,vec.begin()+s+base_days,'V');
	ans=hp/gMaxVolume;
	return ans;
}

int getLabel(vector<Attr> vec,int s,int num){
	double rat=(vec[s].Close-vec[s+num-1].Open)/vec[s+num-1].Open;
	if( rat>=0.095) return 4;
	else if( rat>0.065) return 3;
	else if( rat>0.035) return 2;
	else if( rat>0.005) return 1;
	else if( rat>-0.005) return 0;
	else if( rat>-0.035) return -1;
	else if( rat>-0.065) return -2;
	else if( rat>-0.095) return -3;
	else if( rat<= -0.095) return -4;
}

vector<Instance>  getFeatures(string id,int step){
	vector<Attr> dat=data(id);

	initGlobal(dat);

	vector< Instance > features;

	int len=dat.size();
	int i=0,j=step; int istep=1;
	while(i<len-10*step){
		Instance ins;
		ins.label=getLabel(dat,i,step);
		vector<double> fec;
		fec.clear();
		//最近1天的变化
		fec.push_back( Price_gMax(dat,j));

		fec.push_back( Volume_gMax(dat,j));
		fec.push_back( Price_Close_Open(dat,j));
		fec.push_back( Price_High_Low(dat,j));
		fec.push_back( Price_Close_Low(dat,j));
		fec.push_back( Price_High_Close(dat,j));
		
		//最近1个周期的变化
	    if(step!=1) {
			fec.push_back( Reg_Volume_gMax(dat,j,step*2) );
			fec.push_back( Reg_Price_Close_Open(dat,j,step*2) );	
			fec.push_back( Reg_Price_High_Low(dat,j,step*2) );
			fec.push_back( Reg_Price_Close_Low(dat,j,step*2) );
			fec.push_back( Reg_Price_High_Close(dat,j,step*2) );
		}
		//最近2个周期的变化
		fec.push_back( Reg_Volume_gMax(dat,j,step*2) );
		fec.push_back( Reg_Price_Close_Open(dat,j,step*2) );	
		fec.push_back( Reg_Price_High_Low(dat,j,step*2) );
		fec.push_back( Reg_Price_Close_Low(dat,j,step*2) );
		fec.push_back( Reg_Price_High_Close(dat,j,step*2) );
		//最近3个周期的变化
		fec.push_back( Reg_Volume_gMax(dat,j,step*3) );
		fec.push_back( Reg_Price_Close_Open(dat,j,step*3) );	
		fec.push_back( Reg_Price_High_Low(dat,j,step*3) );
		fec.push_back( Reg_Price_Close_Low(dat,j,step*3) );
		fec.push_back( Reg_Price_High_Close(dat,j,step*3) );
		//最近4个周期的变化
		fec.push_back( Reg_Volume_gMax(dat,j,step*4) );
		fec.push_back( Reg_Price_Close_Open(dat,j,step*4) );	
		fec.push_back( Reg_Price_High_Low(dat,j,step*4) );
		fec.push_back( Reg_Price_Close_Low(dat,j,step*4) );
		fec.push_back( Reg_Price_High_Close(dat,j,step*4) );
		//最近5个周期的变化
		fec.push_back( Reg_Volume_gMax(dat,j,step*5) );
		fec.push_back( Reg_Price_Close_Open(dat,j,step*5) );	
		fec.push_back( Reg_Price_High_Low(dat,j,step*5) );
		fec.push_back( Reg_Price_Close_Low(dat,j,step*5) );
		fec.push_back( Reg_Price_High_Close(dat,j,step*5) );
		//最近6个周期的变化
		fec.push_back( Reg_Volume_gMax(dat,j,step*6) );
		fec.push_back( Reg_Price_Close_Open(dat,j,step*6) );	
		fec.push_back( Reg_Price_High_Low(dat,j,step*6) );
		fec.push_back( Reg_Price_Close_Low(dat,j,step*6) );
		fec.push_back( Reg_Price_High_Close(dat,j,step*6) );
		//最近7个周期的变化
		fec.push_back( Reg_Volume_gMax(dat,j,step*7) );
		fec.push_back( Reg_Price_Close_Open(dat,j,step*7) );	
		fec.push_back( Reg_Price_High_Low(dat,j,step*7) );
		fec.push_back( Reg_Price_Close_Low(dat,j,step*7) );
		fec.push_back( Reg_Price_High_Close(dat,j,step*7) );

		i+=istep;j+=istep;
		ins.feat=fec;
		features.push_back(ins);
	}
	return features;
}

