#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include "../header/data.hpp"
using namespace std;
using namespace stock;
//example:  LRU -d 15 -n 4 -r 0.2 -p 0.05
/*
   -d days default 15 : check how long days
   -n num default 4 : the least time to repeat
   -r rate default 0.2 : the high and low rate can accept
   -p profit default 0.05 : how much to make a profit
*/
struct Ans{
	string id;
	double maxHigh;
	double minLow;
	double high;
	double low;
	double mean;
	double sigma;
	double price;
	int num;
};

int getWalkNumber(vector<Attr> dat,int total,int high,int low){
	int hc=0,lc=0;
	for(int i=0;i<total;i++){
		double h=dat[i].High;
		double l=dat[i].Low;
		if(h>=high) hc++;
		if(l<=low) lc++;
	}
	return min(hc,lc);
}

vector<Ans> FilterStock(int days,int num,double rate,double profit){
	vector<Ans> vs;
	vector<string> ids=idList();
	vector<Attr> dat;
	for(int i=0;i<ids.size();i++){
		string id=ids[i];
		dat=data(id);
		if(dat.size()<=days) continue;

		double  maxHigh=0,minLow=0;
		getHighLow(dat,days,maxHigh,minLow);
		// Filter the wave bigger than rate. and minLow==0.
		if((maxHigh-minLow)>=rate*minLow) continue;

		double high=0,low=0,mean=0,sigma=0;
		getNormal(dat,days,mean,sigma);

		high=mean+sigma;
		low=mean-sigma;
		double curPrice=dat[0].Close;
		//Filter the profit less than profit.
		if((high-curPrice)<=profit*curPrice) continue;

		// Filter the wave number less than num
		int cnt=getWalkNumber(dat,days,high,low);
		if(cnt<num) continue;
		Ans as;
		as.id=id; as.mean=mean;as.sigma=sigma;as.maxHigh=maxHigh;as.minLow=minLow;as.high=high;as.low=low;as.price=dat[0].Close;as.num=cnt;
		vs.push_back(as);
	}
	return vs;
}

int main(int argc,char* argv[]){
	int day=15;
	int num=4;
	double rate=0.2;
	double profit=0.05;
	for(int i=1;i<argc;i++){
		switch (argv[i][1]){
			case 'd': day=atoi(argv[++i]); break;
			case 'n': num=atoi(argv[++i]); break;
			case 'r': rate=atof(argv[++i]); break;
			case 'p': profit=atof(argv[++i]); break;
			default : puts("Parameters Error!"); return 0;
		}
	}
	vector<Ans> vs=FilterStock(day,num,rate,profit);
	printf("  id   num price   mean   high   low  maxHigh minLow\n");	
	for(int i=0;i<vs.size();i++){
		printf("%6s %3d %6.2lf %6.2lf %6.2lf %6.2lf %6.2lf %6.2lf\n",
				vs[i].id.c_str(),vs[i].num,vs[i].price,vs[i].mean,vs[i].high,vs[i].low,vs[i].maxHigh,vs[i].minLow);
	}
	return 0;
}
