#include<stdio.h>
#include <string.h>
#include <stdlib.h>
#include "data.h"
//1  Id
//2 -operation: -value=(V1-V2),-rate = (V1-V2)/V2, -second=(V1-V2)/(V2-V3),
//3 -计算属性 最高h,最低l，开盘o，关闭c,平均m
//4 -计算周期 一周5，二周10，一月20，二个月40，......
//5 -计算长度 number
using namespace std;
using namespace stock;

vector<double> Function(vector< vector<Attr> > dz,char oper,char ways,int days);

int main(int argc,char* argv[]){
	if(argc!=6){
		puts("输入参数错误");
		return 0;
	}
	int wh=SH;
	vector<string> Ids;
	if(strcmp(argv[1],"-sz")==0){
		Ids=IdList(SZ);
		wh=SZ;
	}
	else if(strcmp(argv[1],"-sh")==0){
		Ids=IdList(SH);
		wh=SH;
	}
	else {
		Ids.push_back(string(&argv[1][3]));
		if(argv[1][2]=='z') wh=SZ;
		else wh=SH;
	}

	char oper=argv[2][1];
	char ways=argv[3][1];
	int  days=atoi(&argv[4][1]);
	int  num =atoi(&argv[5][1]);

	for(int i=0;i<Ids.size();i++){
		vector<double> arr=Function(dataSplite(data(Ids[i]),num,days),oper,ways,days);
		if(arr.size()<1) continue;
		printf("%s",Ids[i].c_str());
		for(int j=0;j<arr.size();j++) printf(" %.5lf",arr[j]);
		puts("");
	}

	return 0;
}

vector<double> dFun(vector<double> mz){	
	vector<double> ans;
	for(int i=0;i<mz.size()-1;i++){
		double val=0;
		if(mz[i+1]!=0) val=(mz[i]-mz[i+1])/mz[i+1];
		ans.push_back(val);
	}
	return ans;
}

vector<double> Function(vector< vector<Attr> > dz,char oper,char ways,int days){
	vector<double> mz;
	for(int i=0;i<dz.size();i++){
		vector<Attr> ele=dz[i];
		double value=0;
		for(int j=0;j<ele.size();j++){
			switch (ways){
				case 'h':
					value+=ele[j].High;break;
				case 'l':
					value+=ele[j].Low;break;
				case 'o':
					value+=ele[j].Open;break;
				case 'c':
					value+=ele[j].Close;break;
				default :
					value+=(ele[j].High+ele[j].Low+ele[j].Open+ele[j].Close)/4;break;
			}
		}
		mz.push_back(value/days);
	}
	if(oper=='r'){
		if(mz.size()<2) return vector<double>();
		return dFun(mz);
	}
	else if(oper=='s'){
		if(mz.size()<3) return vector<double>();
		return dFun(dFun(mz));
	}else if(oper=='v'){
		vector<double> ans;
		for(int i=0;i<mz.size()-1;i++){
			double val=0;
			val=(mz[i]-mz[i+1]);
			ans.push_back(val);
		}
		return ans;
	}

	if(mz.size()<1)
		return vector<double>();
	return mz;
}

/*
vector<double> dFun(vector<double> mz){	
	vector<double> ans;
	for(int i=0;i<mz.size()-1;i++){
		double val=0;
		if(mz[i+1]!=0) val=(mz[i]-mz[i+1])/mz[i+1];
		ans.push_back(val);
	}
	return ans;
}*/


/*
vector< vector<Attr> > dataSplite(vector<Attr> dat,int num,int days){
	vector< vector<Attr> > vS;
	vector<Attr> ele;
	for(int i=0;i<dat.size();i++){
		if(i!=0 &&  i%days==0 ){
			vS.push_back(ele);
			ele.clear();
			num--;
			if(num<=0) break;
		}
		ele.push_back(dat[i]);
	}
	return vS;
}
*/
