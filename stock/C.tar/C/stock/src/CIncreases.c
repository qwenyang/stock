#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include "data.hpp"
//examples : CIncreases -d 10 -h 0.25 -n 3 -s 0.03 -r 0.06
using namespace std;
using namespace stock;
//using namespace yangwq;
/*
   -d days default 10 : the lastest days can not decrease
   -h highRate default 0.25 : the biggest wave.

   -n num default 3 : the least days increament
   -s rate default 0.03 : the sigle day to increament
   -r rate default 0.06 : the n days increament
*/

struct Ans{
	string id;
	double maxHigh;
	double minLow;
	double mean;
	double price;
};

vector<Ans> FilterStock(int day,double highRate,int num,double single,double rate){
	vector<Ans> vs;
	vector<string> ids=idList();
	vector<Attr> dat;
	for(int i=0;i<ids.size();i++){
		string id=ids[i];
		dat=data(id);
		if(dat.size()<day) continue;
		if((dat[0].Close-dat[num].Close)>rate*dat[num].Close) continue;
		int j=0;
		for(j=0;j<num;j++) if(dat[j].Close < dat[j].Open ||  (dat[j].Close-dat[j].Open)>single*dat[j].Open) break;
		if(j<num) continue;
		//Volume is increase.
		double mv=meanInVector(dat.begin(),(vector<Attr>::iterator)(&dat[day]),'V' );
		for(j=num-1;j>=0;j--) 
			if(dat[j].Volume>mv) mv=dat[j].Volume;
			else break;
		if(j>=0) continue;
		//price is ok.
		double maxHigh=0,minLow=0,price=0,mean=0,sigma=0;
		getHighLow(dat,day,maxHigh,minLow);
		if( (maxHigh-minLow)>=highRate*minLow ) continue;
		getNormal(dat,day,mean,sigma);
		price=dat[0].Close;
		if(price<=mean) continue;

		Ans as;as.id=id;as.maxHigh=maxHigh;as.minLow=minLow;as.mean=mean;as.price=price;
		vs.push_back(as);
	}
	return vs;
}

int main(int argc,char* argv[]){
	int day=10;
	double highRate=0.25;

	int num=3;
	double single=0.03;
	double rate=0.06;
	for(int i=1;i<argc;i++){
		switch (argv[i][1]){
			case 'n': num=atoi(argv[++i]); break;
			case 'r': rate=atof(argv[++i]); break;
			case 's': single=atof(argv[++i]); break;
			case 'd': day=atoi(argv[++i]); break;
			case 'h': highRate=atof(argv[++i]);break;
			default : puts("Parameters Error!"); return 0;
		}
	}
	vector<Ans> vs=FilterStock(day,highRate,num,single,rate);
	printf("  id   price   mean maxHigh minLow\n");	
	for(int i=0;i<vs.size();i++){
		printf("%6s %6.2lf %6.2lf %6.2lf %6.2lf\n",
				vs[i].id.c_str(),vs[i].price,vs[i].mean,vs[i].maxHigh,vs[i].minLow);
	}
	return 0;
}
