#ifndef DATA_H_H_H

#define DATA_H_H_H

#include <string>
#include <vector>
#include <iostream>
#include <map>
#include <math.h>
#include <stdlib.h>
#include <algorithm>

#include "tool.hpp"
#include "file.hpp"

using namespace std;
using namespace yangwq;

namespace stock{
	const int SH=0;
	const int SZ=1;

	const string fIdList="/home/ubuntu/Data/stock/name_id/IdList";
	const string dHistoryData="/home/ubuntu/Data/stock/history_data/"; 
	
	struct Attr{
		std::string Id;
		std::string Date;
		double Open;
		double High;
		double Low;
		double Close;
		double Volume;
	};

	vector<string> idList(){
		IFile f(fIdList);
		vector<string> vec;
		while(f.hasNext()){
			string line=f.readLine();
			vector<string> vs=split(line);
			if(vs.size()!=4) continue;
			string Id=vs[0]; 
			int wh=vs[1][0]-'0';
			int d=vs[2][0]-'0';
			int h=vs[3][0]-'0';
			if (d==1&&h==1){
				vec.push_back(Id);
			}
		}
		f.close();
		return vec;
	}

	std::vector<Attr> data(string id){
		IFile f(dHistoryData+id);
		vector<Attr> vec;
		while(f.hasNext()){
			Attr at;
			string line=f.readLine();
			if(line.length()<10) break;
			vector<string> vs=split(line);
			if(vs.size()<7) break;
			at.Id=vs[0];
			at.Date=vs[1];
			at.Close=atof(vs[2].c_str());
			at.Open=atof(vs[3].c_str());
			at.High=atof(vs[4].c_str());
			at.Low=atof(vs[5].c_str());
			at.Volume=atoi(vs[6].c_str());
			vec.push_back(at);
		}
		f.close();
		return vec;
	}
	
	vector< vector<Attr> > dataSplit(vector<Attr> dat,int days,int num=0){
		vector< vector<Attr> > vS;
		vector<Attr> ele;
		for(int i=0;i<dat.size();i++){
			if( (i+1)%days==0 ){
				vS.push_back(ele);
				ele.clear();
				num--;
				if(num==0) break;
			}
			ele.push_back(dat[i]);
		}
	    return vS;
	}
	vector<double> extract(vector<Attr> vec,char ch='H'){
		vector<double> val;
		for(int i=0;i<vec.size();i++){
			switch (ch){
				case 'H' : val.push_back(vec[i].High); break;
				case 'O' : val.push_back(vec[i].Open); break;
				case 'C' : val.push_back(vec[i].Close); break;
				case 'L' : val.push_back(vec[i].Low); break;
				case 'V' : val.push_back(vec[i].Volume); break;
				case 'M' : val.push_back((vec[i].Open+vec[i].Close)*0.5); break;
				default  : val.push_back((vec[i].High+vec[i].Open+vec[i].Close+vec[i].Low)*0.25);break;
			}
		}
		return val;
	}

	vector<double> extract(vector<Attr>::iterator begin, vector<Attr>::iterator end,char ch='H'){
		vector<double> val;
		for(vector<Attr>::iterator it=begin;it!=end;++it){
			switch (ch){
				case 'H' : val.push_back((*it).High); break;
				case 'O' : val.push_back((*it).Open); break;
				case 'C' : val.push_back((*it).Close); break;
				case 'L' : val.push_back((*it).Low); break;
				case 'V' : val.push_back((*it).Volume); break;
				case 'M' : val.push_back(((*it).Open+(*it).Close)*0.5); break;
				default  : val.push_back(((*it).High+(*it).Open+(*it).Close+(*it).Low)*0.25); break;
			}	
		}
		return val;
	}
	
	vector< vector<Attr> > dynamicDataSplit(vector<Attr> dat,double rate){
		vector< vector<Attr> > vS;
		vector<Attr> ele;
		vector<double> value=extract(dat,'M');

		int maxIdx=0,minIdx=0;
		double maxVal=value[0],minVal=value[0];
		int slop=0;
		for(int i=1;i<value.size();i++){
			if(slop==0){
				if(value[i]>maxVal) { maxVal=value[i];maxIdx=i;}
				if(value[i]<minVal) { minVal=value[i];minIdx=i;}
				if((maxVal-minVal)>=rate*minVal){
					if(minIdx<maxIdx){ele=vectorSubset(dat,0,minIdx+1);vS.push_back(ele);slop=1;}
					else {ele=vectorSubset(dat,0,maxIdx+1); vS.push_back(ele);slop=-1;}
				}
			}
			else if(slop==1){
				if(value[i]>=maxVal){maxVal=value[i];maxIdx=i;}
				else if((maxVal-value[i])>=rate*value[i]){ele=vectorSubset(dat,minIdx,maxIdx+1);vS.push_back(ele);minVal=value[i];minIdx=i;slop=-1;}
			} else {
				if(value[i]<=minVal){minVal=value[i];minIdx=i;}
				else if((value[i]-minVal)>=rate*minVal){ele=vectorSubset(dat,maxIdx,minIdx+1);vS.push_back(ele);maxVal=value[i];maxIdx=i;slop=1;}
			}
		}
		return vS;
	}
	double maxInVector(vector<Attr> vec,char ch='H'){
		vector<double> val=extract(vec,ch);
		return *max_element(val.begin(),val.end());
	}
	double maxInVector(vector<Attr>::iterator begin,vector<Attr>::iterator end,char ch='H'){
		vector<double> val=extract(begin,end,ch);
		return *max_element(val.begin(),val.end());
	}
	
	double minInVector(vector<Attr> vec,char ch='H'){
		vector<double> val=extract(vec,ch);
		return *min_element(val.begin(),val.end());
	}
	double minInVector(vector<Attr>::iterator begin,vector<Attr>::iterator end,char ch='H'){
		vector<double> val=extract(begin,end,ch);
		return *min_element(val.begin(),val.end());
	}	

	double meanInVector(vector<Attr> vec,char ch='H'){
		vector<double> val=extract(vec,ch);
		double mean=0;
		for(int i=0;i<val.size();i++) mean+=val[i];
		return mean/val.size();
	}
	double meanInVector(vector<Attr>::iterator begin,vector<Attr>::iterator end,char ch='H'){
		vector<double> val=extract(begin,end,ch);
		double mean=0;
	    for(int i=0;i<val.size();i++) mean+=val[i];	
		return mean/val.size();
	}

	double midInVector(vector<Attr> vec,char ch='H'){
		vector<double> v=extract(vec,ch);
		sort(v.begin(),v.end());
		return v[(v.size()+1)/2];
	}
	double midInVector(vector<Attr>::iterator begin,vector<Attr>::iterator end,char ch='H'){
		vector<double> v=extract(begin,end,ch);
		sort(v.begin(),v.end());
		return v[(v.size()+1)/2];
	}
	
	void getHighLow(vector<Attr> dat,int total,double& high,double& low){
		low=1000000000.0;high=0.0;
		for(int i=0;i<total;i++){
			double h=dat[i].High;
			double l=dat[i].Low;
			if(h>high) high=h;
			if(l<low) low=l;
		}
	}

	void getNormal(vector<Attr> dat,int total,double& mean, double& sigma){
		mean=0; sigma=0;
		for(int i=0;i<total;i++){
			mean+=dat[i].High;
			mean+=dat[i].Low;
			mean+=dat[i].Close;
		}
		mean=mean/(3*total);
		for(int i=0;i<total;i++){
			sigma+=(dat[i].High-mean)*(dat[i].High-mean);
			sigma+=(dat[i].Low-mean)*(dat[i].Low-mean);
			sigma+=(dat[i].Close-mean)*(dat[i].Close-mean);
		}
		sigma=sqrt(sigma/(3*total));
	}
}
#endif
