#ifndef FUNCTION_H_H_H
#define FUNCTION_H_H_H

#include <algorithm>
#include "data.hpp"
using namespace std;
using namespace stock;
namespace yangwq{
	void gaussDistribution(vector<double> dat,double& mean, double& sigma){
		int total=dat.size();
		if(total<1) return ;
		mean=0; sigma=0;
		for(int i=0;i<total;i++) mean+=dat[i];
		mean=mean/total;
		for(int i=0;i<total;i++)
			sigma+=(dat[i]-mean)*(dat[i]-mean);
		sigma=sqrt(sigma/total);
	}
};
#endif
