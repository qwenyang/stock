#ifndef TOOL_H_H_H
#define TOOL_H_H_H

#include <string>
#include <vector>
using namespace std;

namespace yangwq{
	//string tool
	vector<string> split(string str,char pat=','){
		vector<string> vs; string s="";
		for(int i=0;i<str.length();i++){
			if(str[i]==pat){
				vs.push_back(s);s="";continue;
			}	   
			s+=str[i];
		}	   
		if (s!="") vs.push_back(s);
		return vs; 
	}

	static string g_splitString;
	static int g_index;
	static char g_sep;
	void loadString(const string& str,char sep=','){g_splitString = str;g_sep=sep;g_index=0;}
	int nextInt(){
		int ans=0,len=g_splitString.length();
		while(g_index < len){	
			if(g_splitString[g_index]==g_sep){g_index++;return ans;}
			ans=ans*10+(g_splitString[g_index++]-'0');
		}
		return ans;
	}
	double nextDouble(){
		double ans=0;
		int len=g_splitString.length();
		bool dot=true;
		double base=0.1;
		while(g_index<len){
			if (g_splitString[g_index]==g_sep){g_index++; return ans;}
			if(g_splitString[g_index]=='.'){
				dot=false;g_index++;continue;
			}
			if(dot) ans=ans*10+(g_splitString[g_index++]-'0');
			else { 
				ans=ans+(g_splitString[g_index++]-'0')*base;
				base*=0.1;
			}
		}
		return ans;
	}
	string nextString(){
		string str="";
		int len=g_splitString.length();
		while(g_index<len){
			if(g_splitString[g_index]==g_sep) {g_index++;return str;}
			str+=g_splitString[g_index++];
		}
		return str;
	}
	
	//vector tool
	template <typename T>
	vector<T> vectorSubset(vector<T> data,int start,int end){
		vector<T> vs;
		for(int i=start;i<end && i<data.size();i++) vs.push_back(data[i]);
		return vs;
	}
};
#endif
