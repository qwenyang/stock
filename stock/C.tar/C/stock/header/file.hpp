#ifndef FILE_H_H_H
#define FILE_H_H_H

#include <fstream>
#include <fstream>
#include <stdlib.h>

using namespace std;

namespace yangwq{
	class IFile{
	private:
		string name;
		ifstream fin;
		char sep;
	public:
		IFile(string f, char p=','):name(f),sep(p){
			fin.open(name.c_str());
		}
		bool hasNext(){
			if(fin.eof()) return false;
			return true;
		}
		string readLine(){
			string str;getline(fin,str);return str;
		}
		void close(){ fin.close();}
	};
	class OFile{
	private:
		string name;
		char sep;
		ofstream fout;
	public:
		OFile(string f,char p=',',bool append=true) : name(f),sep(p) {fout.open(name.c_str());}
		void writeLine(string line){fout<<line<<endl;} 
		void close() {fout.close();}
	};
};//end namespace 
#endif
