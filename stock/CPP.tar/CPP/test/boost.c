
#include<iostream>

//#include "boost/date_time/gregorian/gregorian_types.hpp"
#include "boost/date_time/gregorian/gregorian.hpp"
using namespace std;
int main()
{
	using namespace boost::gregorian;
	string s1,s2;
	while(cin>>s1>>s2){
		date d1 = from_string(s1);
		date d2 = from_string(s2);
		date d;
		date_duration dur=d1-d2;
		cout<<dur.days()<<endl;
	}
	return 0;
}
