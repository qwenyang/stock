#include <stdio.h>
#include <unistd.h>

int main(){
	pid_t pid;
	if( (pid=fork())==0){
		printf("Son\n");
	}else {
		printf("Far\n");
	}
	exit(0);
}
