#ifndef __STDEF_H__
#define __STDEF_H__

#define PTN_B(a)	(a)?puts("YES"):puts("NO");

#define PTN_I(a)	printf("%d\n",a);
#define PIN_I(a,b)		printf("%d %d\n",a,b);
#define PTN_I(a,b,c)		printf("%d %d %d\n",a,b,c);
#define PTN_I(a,b,c,d)			printf("%d %d %d %d\n",a,b,c,d);
#define PTN_I(a,b,c,d,e)			printf("%d %d %d %d %d\n",a,b,c,d,e);


#define PTN_L(a)	printf("%ld\n",a);
#define PIN_L(a,b)		printf("%ld %ld\n",a,b);
#define PTN_L(a,b,c)		printf("%ld %ld %ld\n",a,b,c);
#define PTN_L(a,b,c,d)			printf("%ld %ld %ld %ld\n",a,b,c,d);
#define PTN_L(a,b,c,d,e)			printf("%ld %ld %ld %ld %ld\n",a,b,c,d,e);


#define PTN_D(a)	printf("%lf\n",a);
#define PIN_D(a,b)		printf("%lf %lf\n",a,b);
#define PTN_D(a,b,c)		printf("%lf %lf %lf\n",a,b,c);
#define PTN_D(a,b,c,d)			printf("%lf %lf %lf %lf\n",a,b,c,d);
#define PTN_D(a,b,c,d,e)			printf("%lf %lf %lf %lf %lf\n",a,b,c,d,e);


#define PTN_S(a)	printf("%s\n",a);
#define PIN_S(a,b)		printf("%s %s\n",a,b);
#define PTN_S(a,b,c)		printf("%s %s %s\n",a,b,c);
#define PTN_S(a,b,c,d)			printf("%s %s %s %s\n",a,b,c,d);
#define PTN_S(a,b,c,d,e)			printf("%s %s %s %s %s\n",a,b,c,d,e);
