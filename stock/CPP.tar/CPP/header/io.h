#ifndef __CPP_IO_H__
#define __CPP_IO_H__

#include <sys/stat.h>

namespace io
{
	class Stream
	{
	protected:
		/***
		 *Offset for the file handle from origin.
		***/
		long  _position;
	
		/***
		 * Is this stream closed?
		***/
	    //bool _closed;
	
	public:  
		/***
		 * return the position of the stream. 
		***/
		virtual long getPosition() { return _position;}

		/***
		 * Closes this stream and releases any system 
		 * resources associated with this stream. 
		***/ 
		virtual void close() = 0;
	};

	class InputStream : public Stream
	{
	public:
		/***
		 * Returns the number of bytes that can be read (or skipped over) 
		 * from this input stream without blocking by the next caller of 
	     * a method for this input stream. 
		***/ 
		virtual long available() = 0; 
				      
		/***
	     * Reads the next byte of data from the input stream. 
		***/
		virtual int read() = 0; 
					       
		/***
		 * Reads some number of bytes from the input stream and stores 
		 * them into the buffer array b.
		***/
		virtual int read(char *buf, int nbytes) = 0; 
						        
		/***
		 * Reads up to len bytes of data from the input stream into 
		 * an array of bytes.
		***/
	    virtual int read(char *buf, int off, int nbytes) = 0; 
								     
		/***
		 * Skips over and discards n bytes of data from this input stream. 
		***/
		virtual long skip(long n) = 0; 	
	};

	class OutputStream : public Stream
	{
	public:  
		/***
		 * Flushes this output stream and forces any buffered 
		 * output bytes to be written out.
		***/
		virtual void flush() = 0; 
				    
		/***
		 * Writes len bytes from the specified byte array to 
		 * this output stream. 
		***/ 
		virtual OutputStream& write(const char *buf, int nbytes) = 0; 
					    
        /***
		 * Writes len bytes from the specified byte array to 
		 * this output stream. 
		***/ 
		virtual OutputStream& write(const char *buf, int off, int nbytes) = 0; 

		/**
		 * Writes the specified byte to this output stream. 
		*/ 
		virtual OutputStream& write(int buf) = 0; 

	};

	class AbstractFile
	{
	public: 

		/***
		 * Tests whether the application can read the file denoted by this
		 * abstract pathname.
		***/
		//virtual bool canRead() = 0; 

		/***
		 * Tests whether the application can modify to the file denoted by this
		 * abstract pathname.
		***/
		//virtual bool canWrite() = 0; 

		/***
		 * Tests whether the application can modify and read the file denoted by this
		 * abstract pathname.
		***/
		//virtual bool canReadWrite() = 0; 

	};

	class File : public AbstractFile
	{
	protected:
		/***
		 * The path of the file.
		***/
		const char* _fPath;

		/***
		 * The file description after open the file.
		***/
		int _fd;

		/***
		 * The state variable of the fiel.
		***/
		struct stat _fs;

	public :
		File(const char* path);
		
		/***
		 * Tests whether the application can read the file denoted by this
		 * abstract pathname.
		***/
		//virtual bool canRead(); 

		/***
		 * Tests whether the application can modify to the file denoted by this
		 * abstract pathname.
		***/
		//virtual bool canWrite();

		/***
		 * Tests whether the application can modify and read the file denoted by this
		 * abstract pathname.
		***/
		//virtual bool canReadWrite();

		/***
		 * open
		***/
		int open(int oflag);
	
		/***
		 *Return file description.
		***/
		int getFD(){return _fd;}

		/***
		 *Return the path.
		***/
		const char* getPath(){return _fPath;}

		/***
		 *Judge weather the file is exist.
		***/
		//bool exists();
		
		/***
		 *Judge the file is a directory.
		***/								
		bool isDirectory();
		
		/***
		 *Judge the file is file not a directory.
		**i*/
		bool isFile();
		
		/***
		 *Return the length of the file.
		***/
		long length();
		
		/***
		 *Return the last modified time.
		***/
		//string lastModifiedTime();

		/***
		 * close the file.
		***/
		void close();
	};

	class FileInputStream : public InputStream
	{
	protected:
		File* _file;

	public:
		FileInputStream(char const *path);
//		FileInputStream(const File* file);	

		/***
		 * Returns the number of bytes that can be read (or skipped over) 
		 * from this input stream without blocking by the next caller of 
	     * a method for this input stream. 
		***/ 
		virtual long available() ; 
				      
		/***
	     * Reads the next byte of data from the input stream. 
		***/
		virtual int read() ; 
					       
		/***
		 * Reads some number of bytes from the input stream and stores 
		 * them into the buffer array b.
		***/
		virtual int read(char *buf, int nbytes) ; 
						        
		/***
		 * Reads up to len bytes of data from the input stream into 
		 * an array of bytes.
		***/
	    virtual int read(char *buf, int off, int nbytes) ; 	

		/***
		 * Skips over and discards n bytes of data from this input stream. 
		***/
		virtual long skip(long n) ; 	
	
		/***
		 * Closes this output stream and releases any system 
		 * resources associated with this stream. 
		***/ 
		virtual void close() ;

		~FileInputStream();
	};

	class FileOutputStream : public OutputStream
	{
	protected:
		File* _file;


	public:
		FileOutputStream(char const *path);
		//FileOutputStream(const File* file);

		/***
		 * Flushes this output stream and forces any buffered 
		 * output bytes to be written out.
		***/
		virtual void flush() ; 
				    
		/***
		 * Writes len bytes from the specified byte array to 
		 * this output stream. 
		***/ 
		virtual OutputStream& write(const char *buf, int nbytes) ; 
					    
        /***
		 * Writes len bytes from the specified byte array to 
		 * this output stream. 
		***/ 
		virtual OutputStream& write(const char *buf, int off, int nbytes) ; 

		/**
		 * Writes the specified byte to this output stream. 
		*/ 
		virtual OutputStream& write(int buf) ; 

	    /*** Closes this output stream and releases any system 
		i *resources associated with this stream. 
		***/ 
		virtual void close() ;
		
		~FileOutputStream();
	};
}

#endif
