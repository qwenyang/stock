#ifndef TYPE_H_H_H

#define TYPE_H_H_H

#include <string>
namespace ywq { 
	class Type{
	
	};
	class Int : public Type{
		public:
		int val;

		Int(int v):val(v){}
		int operator int();
	};
	class Double : public Type{
		public:
		double val;

		Double(double v):val(v){}
		double operator double ();
	};
	class String : public Type{
		public:
		std::string val;

		String(std::string v):val(v){}
		std::string operator std::string ();
	};
	class Record : public Type{
		public:
		std::vector<Type> rec;
	};
	class Table : public Type{
		public:
		std::vector<Record> tb;
	};
}
#endif
