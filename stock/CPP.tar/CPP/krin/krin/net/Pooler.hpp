#ifndef KRIN_NET_POLLER_HPP
#define KRIN_NET_POLLER_HPP

#include <pool.h>
#include <vector>

namespace krin{
namespace net{

class Poller{
public:
	Poller(){}
	~Poller(){}
	void Wait(){}

private:
	std::vector<pollfd> fds;
};

}
}
#endif  // KRIN_NET_SOCKET_H
