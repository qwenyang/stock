#ifndef KRIN_NET_ACCEPTOR_H
#define KRIN_NET_ACCEPTOR_H


#include "Socket.hpp"
#include "EventLoop.hpp"


namespace krin{
namespace net{

class Acceptor : public User{
public:
	Acceptor(int pt=0,const char* p="127.0.0.1"):port(pt),ip(p){}
	~Acceptor(){}
	virtual void  Init(){
		serverAddr.sin_family=AF_INET;
		serverAddr.sin_addr.s_addr=inet_addr(address);
		serverAddr.sin_port=htons(port);
		acceptSocket.Bind(&serverAddr);
		acceptSocket.Listen();
	}

	virtual int WaitEvent(){ }
	
	virtual int HandleEvent(){}
	
	virtual int DoneEvent(){}

	virtual void Clear(){}

	int Accept(sockaddr* clientAddr,socklen_t* addrLen){
		return acceptSocket.Accept(clientAddr,addrLen);
	}
private:
	Socket acceptSocket;
	sockaddr_in  serverAddr;
	const int port;
	const char* ip;

};

}
}
#endif  // MUDUO_NET_ACCEPTOR_H
