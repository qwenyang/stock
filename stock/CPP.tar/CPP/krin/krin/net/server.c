#include "Acceptor.hpp"
#include "Buffer.hpp"
int main(int argc,char** argv){
	Acceptor acp(7890);
	acp.Init();

	while(true){	
		Socket csk;
		Buffer buf(csk);

		acp.Accept((sockaddr*)&cliaddr,&clen);
	}
	return 0;
}
