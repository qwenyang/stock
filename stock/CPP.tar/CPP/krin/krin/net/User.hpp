#ifndef KRIN_NET_User_H
#define KRIN_NET_User_H

#include "EventLoop.hpp"

namespace krin{
namespace net{

class User{
public:
	User(EventLoop* loop==NULL):pLoop(loop){}
	
	virtual ~User(){}

	virtual void Init(){};
	virtual int WaitEvent(){};
	virtual int HandleEvent() {};	
	virtual int  DoneEvent(){};
	virtual void Clear(){};
	void run(EventLoop* loop==NULL){ 
		if(loop!=NULL){ pLoop=loop; }
		pLoop->Loop();
	}
private:
	EventLoop* pLoop;
};

}
}

#endif
