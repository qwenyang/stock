#ifndef KRIN_NET_ROBOT_H
#define KRIN_NET_ROBOT_H

namespace krin{
namespace net{

class Robot {
public:
	Robot(){}
	~Robot(){}
private:
	Buffer buf;
};

}
}
#endif  // MUDUO_NET_ACCEPTOR_H
