#ifndef KRIN_NET_BUFFER_H
#define KRIN_NET_BUFFER_H

#include <string.h>
using namespace std;
namespace krin{
namespace net{

class Buffer{
public:
	static const size_t nSize = 1024;
	Buffer(const Socket& sock,char* str==NULL,size_t initSize = nSize):socket(sock){
		size=0;
		pBuf=new char[initSize];
		memset(pBuf,0,sizeof(pBuf));
		if(str!=NULL){
			strcpy(pBuf,str);
			size=strlen(str);
		}
	}
	~Buffer(){delete pBuf;}
	int Append(const char* str){
		int i;
		for(i=0;i<strlen(str);i++) pBuf[i]=str[i];
		return i;
	}
	char* Read(){
		while( (n=::read(socket.Fd(),pBuf+size,nSize))>0){
			size+=n;
		}
		return pBuf;
	}
	int Write(){
		::write(socket.Fd(),pBuf,size);
		return size;
	}
private:
	const Socket& socket;
	char* pBuf;
	int size;
};

}
}

#endif  // KRIN_NET_BUFFER_H
