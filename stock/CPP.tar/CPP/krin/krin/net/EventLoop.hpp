#ifndef KRIN_NET_EVENTLOOP_H
#define KRIN_NET_EVENTLOOP_H

#include "User.h"

namespace krin{
namespace net{

class EventLoop{
public:
	EventLoop(User* us=NULL):pUser(us){}
	~EventLoop(){}
	void Loop(){
		while(true){
			
			pUser->Init();

			pUser->WaitEvent();

			pUser->HandleEvent();
			
			pUser->DoneEvent();
			
			pUser->Clear();
		
		}
	}
private:
	User* pUser;
};

}
}
#endif
