#ifndef KRIN_NET_ACCEPTOR_H
#define KRIN_NET_ACCEPTOR_H


#include "Socket.h"
#include "User.hpp"

namespace krin{
namespace net{

class Connector : public User{
public:
	Connector(EventLoop* loop=NULL,const char* ip="127.0.0.1",const int port) : User(loop),serverPort(port),serverIp(ip){}
	virtual ~Connector(){}
	virtual void Init() {
		serverAddr.sin_family=AF_INET;
		serverAddr.sin_addr.s_addr=inet_addr(serverIp);
		serverAddr.sin_port=htons(serverPort);
		connectSocket.Connect(&serverAddr,sizeof(serverAddr));
	}
	virtual int WaitEvent(){

	}
	virtual int HandleEvent(){
	
	}
	virtual int DoneEvent(){
		
	}
	virtual void Clear() { }
private:
	Socket connectSocket;
	sockaddr_in  serverAddr;
	const int serverPort;
	const char* serverIp;
};

}
}

#endif  // MUDUO_NET_ACCEPTOR_H
