#ifndef KRIN_NET_SOCKET_HPP
#define KRIN_NET_SOCKET_HPP

#include <sys/socket.h>
#include <netinet/in.h>

namespace krin{
namespace net{

class Socket{
public:
	Socket(){sockfd_=socket(AF_INET,SOCK_STREAM,0);}
	~Socket(){close(sockfd_);}
	int Fd() const { return sockfd_; }

	int Bind(const sockaddr *localAddr){
		return ::bind(sockfd_,localAddr,sizeof(*localAddr));		
	}
	int Connect(const sockaddr *serverAddr,socklen_t addrLen){
		return ::connect(sockfd_,serverAddr,addrLen);
	}
	int Listen(int max_num=5){
		return ::listen(sockfd_,max_num);
	}
	int Accept(sockaddr* clientAddr,socklen_t* addrLen){
		return ::accept(sockfd_,clientAddr,addrLen);
	}
private:
	int sockfd_;
};

}
}
#endif  // KRIN_NET_SOCKET_H
