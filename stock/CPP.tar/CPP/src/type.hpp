#ifndef TYPE_H_H_H

#define TYPE_H_H_H

#include <string>
#include <stdlib.h>
#include <vector>
#include <stdio.h>

using namespace std;

namespace yangwq { 

	class Type{
	public:
		virtual ~Type(){}
		virtual string toString()=0;
	};
	
	class Int : public Type{
	public:
		int* val;
		Int(){val=NULL;}
		Int(int v){val=new int(v);} 
		Int(const Int& v){ val=new int(*v.val);}
		Int& operator = (const Int& v){ 
			if( this==&v ) return *this; 
			delete val;
			val=new int(v.val);
		}
		virtual ~Int(){if (val!=NULL) delete val; }
		operator int() const { return *val;} 

		bool isNull(){ return val==NULL;}
		int toInt(){ if(val!=NULL) return *val;}
		virtual string toString(){
			if(val==NULL) return "";
			char str[20];sprintf(str,"%d",*val); 
			return string(str);
		}
	};

	class Double : public Type{
	public:
		double val;
		Double(){}
		Double(double v):val(v){}
		//Double(Type& v){val=v;}
		operator double (){return val;}
		/*string toString(int len){
			char str[20]; 
			switch (len){
				case 0 :  sprintf(str,"%.0lf",val); return string(str);
				case 1 :  sprintf(str,"%.1lf",val); return string(str);
				case 2 :  sprintf(str,"%.2lf",val); return string(str);
				case 3 :  sprintf(str,"%.3lf",val); return string(str);
				case 4 :  sprintf(str,"%.4lf",val); return string(str);
				case 5 :  sprintf(str,"%.5lf",val); return string(str);
				case 6 :  sprintf(str,"%.6lf",val); return string(str);
				case 7 :  sprintf(str,"%.7lf",val); return string(str);
				case 8 :  sprintf(str,"%.8lf",val); return string(str);
				case 9 :  sprintf(str,"%.9lf",val); return string(str);
				case 10 : sprintf(str,"%.10lf",val); return string(str);
				default : sprintf(str,"%.11lf",val); return string(str);
			}
			return "";
		}*/
		virtual string toString(){ char str[20]; sprintf(str,"%.4lf",val); return string(str);}
	};

	class String : public Type{
	private:
		string val;
	public:
		String(){}
		String(string v):val(v){}
		String(const String& v){ val=v.val;}

		//operator string (){return val;}const
		String& operator = (const String& lhs){ 
			if (this==&lhs) return *this;
			val.clear();val.append(lhs.val);
			return *this;
		}

		String operator+(const String& rhs){ return String(val+rhs.val);}
		String operator+(const string& rhs){ return String(val+rhs);}
		String& operator +=(const String& rhs){ val.append(rhs.val); return *this;}
		String& operator +=(const string& rhs){ val.append(rhs); return *this;}

		void clear(){val.clear();}
		virtual string toString(){ return val;}
	};

	class Date : public Type{
	public:
		char sep;
		int year;
		int month;
		int day;
		Date(char p='p'):sep(p){};
		Date(int y,int m,int d,char p='-') : year(y),month(m),day(d),sep(p){}
		Date(std::string v,char p='-'){ sep=p;}
		bool operator <(const Date& da) const{
			if(year != da.year) return year<da.year;
			if(month!=da.month) return month<da.month;
			if(day!=da.day) return day<da.day;
			return false;
		}
		bool operator <=(const Date& da) const{
			if(year != da.year) return year<da.year;
			if(month!=da.month) return month<da.month;
			if(day!=da.day) return day<da.day;
			return true;
		}
		bool operator >(const Date& da) const{	
			if(year != da.year) return year>da.year;
			if(month!=da.month) return month>da.month;
			if(day!=da.day) return day>da.day;
			return false;
		}
		bool operator >=(const Date& da) const{
			if(year != da.year) return year>da.year;
			if(month!=da.month) return month>da.month;
			if(day!=da.day) return day>da.day;
			return true;
		}
		bool operator ==(const Date& da) const{
			return year==da.year && month==da.month && day==da.day;
		}
		//Int operator -(const Date& da) const{}
	private :
		//int minus(const Date& d1,const Date& d2) const {}
	};

	class Vector : public Type{
	public:
		vector<Type*>* rec;
		Vector(){ rec=NULL;}
		Vector(const Vector& v)  
		int size(){ return rec.size();}
		void push(Type t) {rec.push_back(t);}
		Type get(int idx) {return rec[idx];}
		void set(Type t,int idx){rec[idx]=t;}
		void clear(){ rec.clear();}
	//	Int getInt(int idx){ return static_cast<Int> (rec[idx]);}
	//	Double getDouble(int idx){ return static_cast<Double> (rec[idx]);}
	//	String getString(int idx){ return static_cast<String> (rec[idx]);}
	//	Date getDate(int idx){ return static_cast<Date> (rec[idx]);}
	};

	class Table : public Type{
	private:
		std::vector<Record> tb;
	public:
		void push(Record rd){ tb.push_back(rd);}
		Record get(int idx){ return tb[idx];}
		void set(Record rd,int idx){tb[idx]=rd;}
		int size(){ return tb.size();}
		void clear(){ tb.clear();}
	};
}
#endif
