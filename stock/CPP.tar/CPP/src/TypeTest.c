#include "type.hpp"
#include <iostream>

using namespace std;
using namespace yangwq;

int main(){
	Int a(3);
	Int b(4);
	Int c=a+b;
	cout<<c<<endl;
    cout<<c.toString()<<endl;
    Type& x=c;
	cout<<x.toString()<<endl;

	Double pi=1.123;
	Double px=2.134;
	Double as=pi+px;
	cout<<as<<endl;
	
	cout<<as/c<<endl;
	String s1=string("hello ");
	String s2=string("world!");
	String s=s1+s2;
	cout<<s.toString()<<endl;

	vector<Type> vec;
	vec.push_back(a);
	vec.push_back(b);
	vec.push_back(pi);
	vec.push_back(px);
	vec.push_back(s1);
	vec.push_back(s2);

//	for(int i=0;i<vec.size();i++) cout<<vec[i].toString()<<" ";
	cout<<endl;
	return 0;
}
