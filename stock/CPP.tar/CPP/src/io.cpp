#include <fcntl.h>
#include <unistd.h>

#include "io.h"

namespace io{
/****************************************************/
/***************** Start File **********************/
/***************************************************/
File::File(const char* path)
{
	_fPath=path;
	_fd=-1;
}

int File::open(int oflag)
{
	_fd=::open(_fPath,oflag);
	
	fstat(_fd,&_fs);
	//throw FILE_NOT_EXIST and FILE_NOT_OPEN
}

long File::length()
{
	return (long) _fs.st_size;
}

bool File::isFile()
{
	return S_ISREG(_fs.st_mode);
}

bool File::isDirectory()
{
	return S_ISDIR(_fs.st_mode);
}
/*
bool File::canRead()
{
	return S_IRUSR(_fs.st_mode);
}

bool File::canWrite()
{
	return S_IWUSR(_fs.st_mode);
}

bool File::canReadWrite()
{
	return 1;
}*/
void File::close()
{
	::close(_fd);
}
/****************************************************/
/******************* End File ***********************/
/****************************************************/


/****************************************************/
/********** Start FileInputStream  *****************/
/***************************************************/
FileInputStream::FileInputStream(char const *path)
{
	_file=new File(path);
	_file->open(O_RDONLY);
}
/*
FileInputStream::FileInputStream(const File* file)
{
	_fd=open(file->getPath(),O_RDONLY);
	//throw
}*/

int FileInputStream::read()
{
	char b[2];
	int len=::read(_file->getFD(),b,1);
	if(len!=1) return -1;
	_position++;
	return b[0];
}

int FileInputStream::read(char* buf,int nbytes)
{
	int len=::read(_file->getFD(),buf,len);
	_position+=len;
	return len;
}


int FileInputStream::read(char* buf,int off,int nbytes)
{
	int len=::read(_file->getFD(),buf+off,nbytes);
	_position+=len;
	return len;
}

long FileInputStream::available()
{
	long lenf=_file->length();
	return lenf - _position;
}	

long FileInputStream::skip(long n)
{
	lseek(_file->getFD(),n,SEEK_CUR);
	_position+=n;
}

void FileInputStream::close()
{
	_file->close();
}

FileInputStream::~FileInputStream()
{
	delete _file;
}
/*******************************************/
/************ End FileInputStream **********/
/*******************************************/

/*******************************************/
/*********** Start FileOutputStream *******/
/******************************************/

FileOutputStream::FileOutputStream(char const *path)
{
	 _file=new File(path);
	 _file->open(O_WRONLY | O_CREAT );
}

OutputStream& FileOutputStream::write(const char* buf,int nbytes)
{
	::write(_file->getFD(),buf,nbytes);
	_position+=nbytes;
	return *this;
}

OutputStream& FileOutputStream::write(const char* buf,int off,int nbytes)
{
	::write(_file->getFD(),buf+off,nbytes);
	_position+=nbytes;
	return *this;
}

OutputStream& FileOutputStream::write(int buf)
{
	char b=(char) buf;
	::write(_file->getFD(),&b,1);
	_position+=1;
	return *this;
}

void FileOutputStream::flush()
{
	::fsync(_file->getFD());
}

void FileOutputStream::close()
{
	_file->close();
}
/******************************************/
/*********** End FileOutputStream *********/
/*****************************************/

}
