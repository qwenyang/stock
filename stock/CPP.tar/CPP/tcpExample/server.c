#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sys/socket.h>
#include <netinet/in.h>

#include <arpa/inet.h>
#include <unistd.h>

const char* address="127.0.0.1";
const int port=2345;
const int max_listen=100;
const int max_line=1000;

void str_echo(int sockfd){
	size_t n;
	char buf[max_line];
	while( (n=read(sockfd,buf,max_line))>0) 
		write(sockfd,buf,n);
}

int main(int argc,char** argv){
	int listenfd,connfd;
	pid_t childpid;
	socklen_t clen;
	struct sockaddr_in cliaddr,servaddr;

	listenfd=socket(AF_INET,SOCK_STREAM,0);
	memset(&servaddr,0,sizeof(servaddr));
	memset(&cliaddr,0,sizeof(cliaddr));

	servaddr.sin_family=AF_INET;
	servaddr.sin_addr.s_addr=inet_addr(address);
	servaddr.sin_port=htons(port);

	bind(listenfd,(sockaddr*)&servaddr,sizeof(servaddr));
	listen(listenfd,max_listen);
	while(true){
		clen=sizeof(cliaddr);
		connfd=accept(listenfd,(sockaddr*)&cliaddr,&clen);
		if( (childpid=fork()==0)){
			close(listenfd);
			str_echo(connfd);
			exit(0);
		}
		close(connfd);
	}
	return 0;
}
