#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>

const char* address="127.0.0.1";
const int port=2345;
const int max_line=1000;

void str_cli(int sockfd){
	size_t n;
	pid_t pid;
	char buf[max_line],bufr[max_line];
	if( (pid=fork())==0){
		printf("C\n");
		while(scanf("%s",buf)!=EOF){
			printf("BA\n");
			size_t n=(size_t) strlen(buf);
			write(sockfd,buf,n);
			printf("A\n");
		}
	}else {
		int n;
		printf("F\n");
		while( (n=read(sockfd,bufr,max_line))>0)
			printf("%s\n",bufr);
	}
}

int main(int argc,char **argv){
	int sockfd;
	sockaddr_in servaddr;
	sockfd=socket(AF_INET,SOCK_STREAM,0);

	memset(&servaddr,0,sizeof(servaddr));
	servaddr.sin_family=AF_INET;
	servaddr.sin_port=htons(port);
	inet_pton(AF_INET,address,&servaddr.sin_addr);
    int rt=connect(sockfd,(sockaddr*)&servaddr,sizeof(servaddr));
	printf("Connect %d \n",rt);
	str_cli(sockfd);
	exit(0);
}
