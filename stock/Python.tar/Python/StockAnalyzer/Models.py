import os
import numpy as np
from numpy import random
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import AdaBoostClassifier
from sklearn import svm
from sklearn.ensemble import BaggingClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeRegressor
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import AdaBoostRegressor
from stockdata import idList
from stockdata import dataStock
from stockdata import writeTable
from stockdata import splitAttr
from stockdata import initGlobal

g_data_dir="/home/ubuntu/Data/stock/history_data/"
g_dfeatures_week="/home/ubuntu/Data/stock/features_week/"
g_dfeatures_day="/home/ubuntu/Data/stock/features_day/"
g_fclassfication_day="/home/ubuntu/Data/stock/ans/class_day"
g_fclassfication_week="/home/ubuntu/Data/ans/stock/class_week"


def readFeature(fPath):
	fea=[]
	targ=[]
	f=open(fPath)
	dat=f.readlines()
	num=0
	for line in dat:
		att = line.split(',')
		y=float(att[0])
		lab=0
		num=num+1;
		if num>=300:
			break
		if y>=0.08:
			lab=1
		else:
			lab=-1
		if lab==-1 and num>5 and random.randn()>1.2:
			continue

		targ=targ+[lab,]
		x=[]
		ln=len(att)
		for a in att[1:ln-1]:
			x=x+[float(a),]
		fea=fea+[x,]
	return fea,targ
		
def stockModel(mode):
	dFea=""
	fOut=""
	if mode==1:
		dFea=g_dfeatures_day
		fOut=g_fclassfication_day	
	elif mode==5:
		dFea=g_dfeatures_week
		fOut=g_fclassfication_week
	ids=idList()
	ans=[]
	rng = np.random.RandomState(1)
	train_X=[]
	train_Y=[]
	for cid in ids:
		(tX,tY)=readFeature(dFea+cid)
		train_X=train_X+tX[2:]
		train_Y=train_Y+tY[2:]
	regressionFunc = AdaBoostClassifier(DecisionTreeClassifier(max_depth=15),n_estimators=300)
	train_sco=regressionFunc.fit(train_X[2:],train_Y[2:]).score(train_X[2:],train_Y[2:])
	for cid in ids:
		(train_X,train_Y)=readFeature(dFea+cid)
#		regressionFunc = AdaBoostClassifier(DecisionTreeClassifier(max_depth=6),n_estimators=100)
#		regressionFunc = AdaBoostClassifier(DecisionTreeClassifier(max_depth=6),algorithm="SAMME",n_estimators=50)
#regressionFunc = AdaBoostRegressor(DecisionTreeRegressor(max_depth=10),n_estimators=300, random_state=rng)
#train_sco=regressionFunc.fit(train_X[2:],train_Y[2:]).score(train_X[2:],train_Y[2:])
		s=regressionFunc.predict(train_X[0:2])
		ans=ans+[(cid, s[1],train_Y[1],s[0],train_Y[0]),]
		print ans

stockModel(1)
