import urllib

def test():
	url='http://nuff.eastmoney.com/EM_Finance2015TradeInterface/JS.ashx?id=6030281&token=beb0a0047196124721f56b0f0ff5a27c&cb=callback008799506351351738&callback=callback008799506351351738&_=1460872955452'
	page = urllib.urlopen(url)
	html = page.read()
	print html

test()
