import os

g_data_dir="/home/ubuntu/Data/stock/history_data/"


def idList(df):
	lt=()
	for f in os.listdir(df):
		if os.path.isfile(os.path.join(df,f)):
			lt = (lt,f)
	return lt

def dataStock(sid):
	f=open(g_data_dir+sid)
	a=f.readlines()
	da
	for line in a:
		(sid,date,close,openv,high,low,volume)=splitAttr(line)

	f.close
	return a

def splitAttr(line)
	 att = line.split(',')
	 sid = att[0]
	 date = att[1]

	 close = float(att[2])
	 openv = float(att[3])
	 high = float(att[4])
	 low = float(att[5])
	 volume= long(att[6])
     return (sid,date,close,openv,high,low,volume)
