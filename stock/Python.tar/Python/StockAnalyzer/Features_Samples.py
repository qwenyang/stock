#!/usr/bin/python
from stockdata import idList
from stockdata import dataStock
from stockdata import writeTable
from stockdata import splitAttr
from stockdata import initGlobal

g_features_samples="/home/ubuntu/Data/stock/samples/"

def extractFeatures(data):
	length=len(data)
	maxPrice,minPrice,meanPrice,maxVolume,minVolume,meanVolume= initGlobal(data)
	All_Features=[]
	for i in range(0,length-11):
		lineC=data[i]
		(idc,datec,closec,openc,highc,lowc,volumec)=splitAttr(lineC)
		lineO=data[i+step-1]
		(ido,dateo,closeo,openo,higho,lowo,volumeo)=splitAttr(lineO)
		lb= (closec-openo)/closec
		label=[lb,]
		
		j=i+step
		line=data[j]
		(idb,dateb,closeb,openb,highb,lowb,volumeb)=splitAttr(line)	
		fea_1 = closeb/maxPrice
		fea_2 = volumeb/maxVolume 
		fea_3 = (closeb-openb)/openb
		fea_4 = (highb-lowb)/closeb
		fea_5 = (highb-closeb)/closeb
		fea_6 = (closeb-lowb)/closeb
		

		j=i+2*step
		line=data[j]
		(idb,dateb,close1,open1,high1,low1,volume1)=splitAttr(line)	
		fea_7 = (open1-closeb)/closeb
		fea_8 = high1/maxPrice
		fea_9 = volume1/maxVolume 
		fea_10 = (close1-open1)/open1
		fea_11 = (high1-low1)/close1
		fea_12 = (high1-close1)/close1
		fea_13 = (close1-low1)/close1
			
		j=i+3*step
		line=data[j]
		(idb,dateb,close1,open1,high1,low1,volume1)=splitAttr(line)	
		fea_14 = (open1-closeb)/closeb
		fea_15 = high1/maxPrice
		fea_16 = volume1/maxVolume 
		fea_17 = (close1-open1)/open1
		fea_18 = (high1-low1)/close1
		fea_19 = (high1-close1)/close1
		fea_20 = (close1-low1)/close1

		
		j=i+4*step
		line=data[j]
		(idb,dateb,close1,open1,high1,low1,volume1)=splitAttr(line)	
		fea_21 = (open1-closeb)/closeb
		fea_22 = high1/maxPrice
		fea_23 = volume1/maxVolume 
		fea_24 = (close1-open1)/open1
		fea_25 = (high1-low1)/close1
		fea_26 = (high1-close1)/close1
		fea_27 = (close1-low1)/close1


		j=i+5*step
		line=data[j]
		(idb,dateb,close1,open1,high1,low1,volume1)=splitAttr(line)	
		fea_28 = (open1-closeb)/closeb
		fea_29 = high1/maxPrice
		fea_30 = volume1/maxVolume 
		fea_31 = (close1-open1)/open1
		fea_32 = (high1-low1)/close1
		fea_33 = (high1-close1)/close1
		fea_34 = (close1-low1)/close1


		j=i+6*step
		line=data[j]
		(idb,dateb,close1,open1,high1,low1,volume1)=splitAttr(line)	
		fea_35 = (open1-closeb)/closeb
		fea_36 = high1/maxPrice
		fea_37 = volume1/maxVolume 
		fea_38 = (close1-open1)/open1
		fea_39 = (high1-low1)/close1
		fea_40 = (high1-close1)/close1
		fea_41 = (close1-low1)/close1
		

		j=i+7*step
		line=data[j]
		(idb,dateb,close1,open1,high1,low1,volume1)=splitAttr(line)	
		fea_42 = (open1-closeb)/closeb
		fea_43 = high1/maxPrice
		fea_44 = volume1/maxVolume 
		fea_45 = (close1-open1)/open1
		fea_46 = (high1-low1)/close1
		fea_47 = (high1-close1)/close1
		fea_48 = (close1-low1)/close1
		

		j=i+8*step
		line=data[j]
		(idb,dateb,close1,open1,high1,low1,volume1)=splitAttr(line)	
		fea_49 = (open1-closeb)/closeb
		fea_50 = high1/maxPrice
		fea_51 = volume1/maxVolume 
		fea_52 = (close1-open1)/open1
		fea_53 = (high1-low1)/close1
		fea_54 = (high1-close1)/close1
		fea_55 = (close1-low1)/close1


		j=i+9*step
		line=data[j]
		(idb,dateb,close1,open1,high1,low1,volume1)=splitAttr(line)	
		fea_56 = (open1-closeb)/closeb
		fea_57 = high1/maxPrice
		fea_58 = volume1/maxVolume 
		fea_59 = (close1-open1)/open1
		fea_60 = (high1-low1)/close1
		fea_61 = (high1-close1)/close1
		fea_62 = (close1-low1)/close1


		j=i+10*step
		line=data[j]
		(idb,dateb,close1,open1,high1,low1,volume1)=splitAttr(line)	
		fea_63 = (open1-closeb)/closeb
		fea_64 = high1/maxPrice
		fea_65 = volume1/maxVolume 
		fea_66 = (close1-open1)/open1
		fea_67 = (high1-low1)/close1
		fea_68 = (high1-close1)/close1
		fea_69 = (close1-low1)/close1
		features=[fea_1,fea_2,fea_3,fea_4,fea_5,fea_6,fea_7,fea_8,fea_9,fea_10,fea_11,fea_12,fea_13,fea_14,fea_15,fea_16,fea_17,fea_18,fea_19,fea_20,
				  fea_21,fea_22,fea_23,fea_24,fea_25,fea_26,fea_27,fea_28,fea_29,fea_30,fea_31,fea_32,fea_33,fea_34,fea_35,fea_36,fea_37,fea_38,fea_39,
				  fea_40,fea_41,fea_42,fea_43,fea_44,fea_45,fea_46,fea_47,fea_48,fea_49,fea_50,fea_51,fea_52,fea_53,fea_54,fea_55,fea_56,fea_57,fea_58,
				  fea_59,fea_60,fea_61,fea_62,fea_63,fea_64,fea_65,fea_66,fea_67,fea_68,fea_69]
		
		
		All_Features=All_Features+[label+features]
	return All_Features

def features(step):
	if step < 3 :
		df =str(g_features_day)
	else :
		df =str(g_features_week)

	ids=idList()
	for sid in ids:
		data=dataStock(sid)
		ret=extractFeatures_base(data,step)
		writeTable(df+str(sid),ret)
		

step=1
features(step)
