import os

def idList():
	df="/home/ubuntu/Data/stock/history_data/"
	lt=[]
	for f in os.listdir(df):
		if os.path.isfile(os.path.join(df,f)):
			if f.isdigit():
				lt  =lt+[f]
	return lt

def dataStock(sid):
	g_data_dir="/home/ubuntu/Data/stock/history_data/"
	f=open(g_data_dir+sid)
	fx=f.readlines()
	sx=[]
	for a in fx:
		a=a.strip('\n')
		sx=sx+[a,]
	f.close
	return sx

def writeTable(fname,lst,pat=','):
	f=open(fname,"w")
	for tb in lst:
		sline=""
		for at in tb:
			sline=sline+str(at)
			sline=sline+pat
		f.write(sline+"\n")
	f.close()


def splitAttr(line):
	att = line.split(',')
	sid = att[0]
	date = att[1]
	close = float(att[2])
	openv = float(att[3])
	high = float(att[4])
	low = float(att[5])
	volume= float(att[6])
	return (sid,date,close,openv,high,low,volume)

def initGlobal(data):
	maxPrice=0.0
	minPrice=1000000000.0
	maxVolume=0.0
	minVolume=1000000000.0
	sumPrice=0.0
	sumVolume=0.0
	num=len(data)
	for line in data:
		att=line.split(',')
		close=float(att[2])
		openv=float(att[3])
		high=float(att[4])
		low =float(att[5])
		volume =float(att[6])
		sumPrice=sumPrice+(close+openv+high+low)*0.25;
		sumVolume=sumVolume+volume
		if high > maxPrice:
			maxPrice =high
		if low < minPrice:
			minPrice =low
		if volume > maxVolume:
			maxVolume=volume
		elif low < minVolume: 
			minVolume=low
		meanPrice=sumPrice/num
		meanVolume=sumVolume/num
	return maxPrice,minPrice,meanPrice,maxVolume,minVolume,meanVolume

