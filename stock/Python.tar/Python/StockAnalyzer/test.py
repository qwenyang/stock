import os
from  stockdata import idList

print idList()
