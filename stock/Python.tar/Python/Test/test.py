#!/usr/bin/python

a=1
b=a
c=2
b=c
print a,b




